import os
from tqdm import tqdm
import matplotlib.pyplot as plt
import csv
import math
import random
import numpy as np
import pandas as pd

from sklearn import neighbors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, f1_score
from sklearn.metrics import classification_report

from PIL import Image
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

train_df = pd.read_csv("fashion-mnist_train.csv")
test_df = pd.read_csv("fashion-mnist_test.csv")

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']


def data_augmentation(rot=25, crop=True, hflip=True, vflip=True):
    transform_list = []

    if rot:
        transform_list.append(transforms.RandomRotation(rot))
    if crop:
        transform_list.append(transforms.RandomResizedCrop(28, scale=(0.9, 1.0)))
    if hflip:
        transform_list.append(transforms.RandomHorizontalFlip())
    if vflip:
        transform_list.append(transforms.RandomVerticalFlip())

    transform_list.append(transforms.ToTensor())
    transform_list.append(transforms.Normalize(mean=[0.5], std=[0.5]))

    return transforms.Compose(transform_list)

X_train = train_df.iloc[:, 1:].values  # Pixel values
y_train = train_df.iloc[:, 0].values   # Labels
#print(X_train)
X_test = test_df.iloc[:, 1:].values
y_test = test_df.iloc[:, 0].values

print(f"Training samples: {X_train.shape}, Test samples: {X_test.shape}")

augment = data_augmentation(rot=25, crop=True, hflip=True, vflip=True)

# Augmentation loop
X_aug = []
y_aug = []

for i in range(len(X_train)):
    # Prepare raw image
    img_array = X_train[i].reshape(28, 28).astype(np.uint8)
    img = Image.fromarray(img_array)

    # Apply transform
    transformed = augment(img)  # Tensor: (1, 28, 28), normalized [-1, 1]
    transformed_np = transformed.numpy().squeeze()  # Shape (28, 28)

    # Convert to flat array
    X_aug.append(transformed_np.flatten())
    y_aug.append(y_train[i])

# Combine original and augmented data
scaler = StandardScaler()
X_train_combined = np.vstack([X_train, X_aug])
y_train_combined = np.hstack([y_train, y_aug])

print(f"After augmentation: {X_train_combined.shape}, {y_train_combined.shape}")

#print(X_train)
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
print(f"Before augmentation: {X_train.shape}, {y_train.shape}")
#print(X_train)

output_file = "knn_results.txt"
metrics = ['euclidean', 'manhattan', 'chebyshev', 'cosine']
with open(output_file, "w") as f:
    f.write("-" * 50 + "\n")
    for metric in metrics:
        f.write(f"\nTesting distance metric: {metric} ")           
        for k in range(1, 21):
            knn = KNeighborsClassifier(n_neighbors=k, metric=metric)
            knn.fit(X_train, y_train)
            y_train_pred = knn.predict(X_train)
            y_test_pred = knn.predict(X_test)

            # Accuracy
            train_acc = accuracy_score(y_train, y_train_pred)
            test_acc = accuracy_score(y_test, y_test_pred)

            report = classification_report(y_test, y_test_pred, target_names=class_names)
            print(train_acc, test_acc)
            f.write(f"k = {k:2d} | Train Acc = {train_acc:.4f} | Test Acc = {test_acc:.4f}\n")
            f.write(report + "\n")
            f.write("=" * 60 + "\n")
        print(f"[✓] Completed metric: {metric}")

output_file_aug = "knn_results_augmented.txt"
with open(output_file_aug, "w") as f:
    f.write("k\tTrain_Acc\tTest_Acc\n")
    f.write("-" * 50 + "\n")
    for metric in metrics:
        f.write(f"\nTesting distance metric: {metric} ")           
        for k in range(1, 21):
            knn = KNeighborsClassifier(n_neighbors=k, metric=metric)
            knn.fit(X_train_combined, y_train_combined)
            y_train_pred = knn.predict(X_train_combined)
            y_test_pred = knn.predict(X_test)

            # Accuracy
            train_acc = accuracy_score(y_train_combined, y_train_pred)
            test_acc = accuracy_score(y_test, y_test_pred)

            report = classification_report(y_test, y_test_pred, target_names=class_names)

            f.write(f"k = {k:2d} | Train Acc = {train_acc:.4f} | Test Acc = {test_acc:.4f}\n")
            f.write(report + "\n")
            f.write("=" * 60 + "\n")
        print(f"[✓] Completed metric: {metric}")

